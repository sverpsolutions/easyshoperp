<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'auth/index';
$route['404_override']       = '';
$route['translate_uri_dashes'] = FALSE;

// ── Auth ──────────────────────────────────────────────────────
$route['api/auth/login']        = 'auth/login';
$route['api/auth/logout']       = 'auth/logout';
$route['api/auth/me']           = 'auth/me';
$route['api/auth/change-password'] = 'auth/change_password';

// ── Dashboard ─────────────────────────────────────────────────
$route['api/dashboard']         = 'dashboard/index';
$route['api/dashboard/machines']= 'dashboard/machines';

// ── Jobs ──────────────────────────────────────────────────────
$route['api/jobs']              = 'jobs/index';
$route['api/jobs/(:num)']       = 'jobs/show/$1';
$route['api/jobs/store']        = 'jobs/store';
$route['api/jobs/update/(:num)']= 'jobs/update/$1';
$route['api/jobs/delete/(:num)']= 'jobs/delete/$1';
$route['api/jobs/start']        = 'jobs/start';
$route['api/jobs/stop']         = 'jobs/stop';
$route['api/jobs/log']          = 'jobs/log_production';
$route['api/jobs/next-number']  = 'jobs/next_number';

// ── Machines ──────────────────────────────────────────────────
$route['api/machines']              = 'machines/index';
$route['api/machines/(:num)']       = 'machines/show/$1';
$route['api/machines/store']        = 'machines/store';
$route['api/machines/update/(:num)']= 'machines/update/$1';
$route['api/machines/delete/(:num)']= 'machines/delete/$1';
$route['api/machines/status']       = 'machines/live_status';

// ── Employees ─────────────────────────────────────────────────
$route['api/employees']              = 'employees/index';
$route['api/employees/(:num)']       = 'employees/show/$1';
$route['api/employees/store']        = 'employees/store';
$route['api/employees/update/(:num)']= 'employees/update/$1';
$route['api/employees/delete/(:num)']= 'employees/delete/$1';
$route['api/employees/operators']    = 'employees/operators';

// ── Customers ─────────────────────────────────────────────────
$route['api/customers']              = 'customers/index';
$route['api/customers/(:num)']       = 'customers/show/$1';
$route['api/customers/store']        = 'customers/store';
$route['api/customers/update/(:num)']= 'customers/update/$1';
$route['api/customers/delete/(:num)']= 'customers/delete/$1';

// ── Attendance ────────────────────────────────────────────────
$route['api/attendance']        = 'attendance/index';
$route['api/attendance/mark']   = 'attendance/mark';
$route['api/attendance/update/(:num)'] = 'attendance/update/$1';

// ── Advances ──────────────────────────────────────────────────
$route['api/advances']              = 'advances/index';
$route['api/advances/store']        = 'advances/store';
$route['api/advances/approve/(:num)']= 'advances/approve/$1';
$route['api/advances/reject/(:num)'] = 'advances/reject/$1';
$route['api/advances/pay/(:num)']    = 'advances/pay/$1';

// ── Bills ─────────────────────────────────────────────────────
$route['api/bills']              = 'bills/index';
$route['api/bills/(:num)']       = 'bills/show/$1';
$route['api/bills/store']        = 'bills/store';
$route['api/bills/update/(:num)']= 'bills/update/$1';
$route['api/bills/delete/(:num)']= 'bills/delete/$1';
$route['api/bills/next-number']  = 'bills/next_number';

// ── Reports ───────────────────────────────────────────────────
$route['api/reports/daily']       = 'reports/daily';
$route['api/reports/operator']    = 'reports/operator';
$route['api/reports/machine']     = 'reports/machine';
$route['api/reports/customer']    = 'reports/customer';
$route['api/reports/completion']  = 'reports/completion';
$route['api/reports/overdue']     = 'reports/overdue';
$route['api/reports/impressions'] = 'reports/impressions';

// ── Settings ──────────────────────────────────────────────────
$route['api/settings']        = 'settings/index';
$route['api/settings/update'] = 'settings/update';

// ── Suppliers ─────────────────────────────────────────────────
$route['api/suppliers']                  = 'suppliers/index';
$route['api/suppliers/dropdown']         = 'suppliers/dropdown';
$route['api/suppliers/(:num)']           = 'suppliers/show/$1';
$route['api/suppliers/store']            = 'suppliers/store';
$route['api/suppliers/update/(:num)']    = 'suppliers/update/$1';
$route['api/suppliers/delete/(:num)']    = 'suppliers/delete/$1';

// ── Purchase ──────────────────────────────────────────────────
$route['api/purchase']                  = 'purchase/index';
$route['api/purchase/next-number']      = 'purchase/next_number';
$route['api/purchase/summary']          = 'purchase/summary';
$route['api/purchase/(:num)']           = 'purchase/show/$1';
$route['api/purchase/store']            = 'purchase/store';
$route['api/purchase/update/(:num)']    = 'purchase/update/$1';
$route['api/purchase/delete/(:num)']    = 'purchase/delete/$1';

// ── Conversion / Slitting ─────────────────────────────────────
$route['api/conversion']                = 'conversion/index';
$route['api/conversion/next-number']    = 'conversion/next_number';
$route['api/conversion/(:num)']         = 'conversion/show/$1';
$route['api/conversion/store']          = 'conversion/store';
$route['api/conversion/update/(:num)']  = 'conversion/update/$1';
$route['api/conversion/delete/(:num)']  = 'conversion/delete/$1';

// ── Items (Item Master) ───────────────────────────────────────
$route['api/items']                         = 'items/index';
$route['api/items/hierarchy']               = 'items/hierarchy';
$route['api/items/(:num)']                  = 'items/show/$1';
$route['api/items/store']                   = 'items/store';
$route['api/items/update/(:num)']           = 'items/update/$1';
$route['api/items/delete/(:num)']           = 'items/delete/$1';
$route['api/items/groups/store']            = 'items/store_group';
$route['api/items/groups/update/(:num)']    = 'items/update_group/$1';
$route['api/items/subgroups/store']         = 'items/store_subgroup';
$route['api/items/categories/store']        = 'items/store_category';
$route['api/items/subcategories/store']     = 'items/store_subcategory';
$route['api/items/brands/store']            = 'items/store_brand';

// ── Upload ────────────────────────────────────────────────────
$route['api/upload/image']    = 'upload/image';

// ── Operator ──────────────────────────────────────────────────
$route['api/operator/dashboard'] = 'operator/dashboard';
$route['api/operator/request']   = 'operator/request_job';
$route['api/operator/impressions/log'] = 'operator/log_impressions';
